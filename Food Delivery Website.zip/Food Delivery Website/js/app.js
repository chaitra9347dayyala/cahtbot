let cart = [];

// Function to add item to the cart
function addToCart(item) {
  cart.push(item);
  alertPopup(`${item} added to cart!`);
  updateCartDisplay();
}

// Function to display a temporary alert popup
function alertPopup(message) {
  const popup = document.createElement("div");
  popup.classList.add("popup");
  popup.innerText = message;
  document.body.appendChild(popup);

  setTimeout(() => {
    popup.classList.add("show");
  }, 100);

  setTimeout(() => {
    popup.classList.remove("show");
    setTimeout(() => {
      popup.remove();
    }, 300);
  }, 2000);
}

// Function to update cart display
function updateCartDisplay() {
  const cartDiv = document.getElementById("cart");
  cartDiv.innerHTML = "";
  cart.forEach(item => {
    const itemDiv = document.createElement("div");
    itemDiv.innerText = item;
    cartDiv.appendChild(itemDiv);
  });
}
