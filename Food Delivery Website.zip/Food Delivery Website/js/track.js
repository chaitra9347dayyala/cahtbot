document.querySelector("button").onclick = function() {
    document.getElementById("orderStatus").innerText = "Order Status: Out for Delivery";
  };
  